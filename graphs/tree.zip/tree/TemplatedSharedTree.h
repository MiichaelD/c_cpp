
#ifndef TEMPLATEDTREE_H
#define TEMPLATEDTREE_H

#include <vector>
#include <memory>

namespace Tree{

	template<class T> class Node{
	private:
		T m_value;
		std::shared_ptr<Node> m_left, m_right;
		
	public:
		Node(const T &val):m_value(val){}

		T &setValue(const T &val){
			m_value = val;
			return m_value;
		}

		const T& value() const {
			return m_value;
		}
		
		std::shared_ptr<Node> &left(){
			return m_left;
		}

		std::shared_ptr<Node> addLeftNode(const T &val){
			m_left = std::make_shared<Node>(val);
			return m_left;
		}

		std::shared_ptr<Node> addLeftNode(const std::shared_ptr<Node<T>> &other){
			m_left = other;
			return m_left;
		}

		std::shared_ptr<Node> &right(){
			return m_right;
		}

		std::shared_ptr<Node> addRightNode(const T &val){
			m_right = std::make_shared<Node>(val);
			return m_right;
		}

		std::shared_ptr<Node> addRightNode(const std::shared_ptr<Node<T>> &other){
			m_right = other;
			return m_right;
		}

	};

	template<class T>
	std::shared_ptr<Node<T>> createTreeFromVector(std::vector<int> &array, int start, int end);

	template<class T> void printInOrder(std::shared_ptr<Node<T>> root);

};


#endif //TEMPLATEDTREE_H