
#include "TemplatedSharedTree.h"
#include <iostream>

int main(){	
	using namespace std;
	using namespace Tree;
	vector<int> array = {0,1,2,3,4,5,6,7,8,9};
	auto root = createTreeFromVector<int>(array, 0, array.size()-1);
	printInOrder(root);
	cout << endl << endl;
	return 0;
}