
#include "TemplatedSharedTree.h"
#include <iostream>

// #include <memory> -> included in .h
// #include <vector> -> included in .h

template<class T>
std::shared_ptr<Tree::Node<T>> Tree::createTreeFromVector(std::vector<int> &array, int start, int end){
	if (start > end)
		return std::shared_ptr<Tree::Node<T>>(nullptr);
	int mid = (end + start) / 2;
	std::shared_ptr<Tree::Node<T>> node = std::make_shared<Tree::Node<T>>(array[mid]);
	node->addLeftNode( createTreeFromVector<T>(array, start, mid-1) );
	node->addRightNode( createTreeFromVector<T>(array, mid+1, end) );
	return node;
}

template<class T>
void Tree::printInOrder(std::shared_ptr<Tree::Node<T>> root){
	if (root == nullptr)
		return;

	printInOrder(root->left());
	std::cout << root->value() << " ";
	printInOrder(root->right());
}

// int main(){	
// 	using namespace std;
// 	using namespace Tree;
// 	vector<int> array = {0,1,2,3,4,5,6,7,8,9};
// 	auto root = createTreeFromVector<int>(array, 0, array.size()-1);
// 	printInOrder(root);
// 	cout << endl << endl;
// 	return 0;
// }